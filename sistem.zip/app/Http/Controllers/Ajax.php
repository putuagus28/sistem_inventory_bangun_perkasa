<?php

namespace App\Http\Controllers;

use App\Mahasiswa;
use App\Ukm;
use App\AnggotaUkm;
use App\Pemasukan;
use App\Pembayaran;
use App\Pengeluaran;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use App\Barang;
use App\User;
use Illuminate\Support\Carbon;
use Illuminate\Support\Facades\Session;
use Illuminate\Support\Facades\DB;

class Ajax extends Controller
{

    public function kodeBarang(){
        $max = Barang::max('kode');
        $kodeBarang = $max;
        // mengambil angka dari kode barang terbesar, menggunakan fungsi substr
        // dan diubah ke integer dengan (int)
        $urutan = (int) substr($kodeBarang, 3, 3);
        $urutan++;
        $huruf = "BRG";
        $kode = $huruf . sprintf("%03s", $urutan);
        return $kode;
    }


    function hari($date)
    {
        $daftar_hari = array(
            'Sunday' => 'Minggu',
            'Monday' => 'Senin',
            'Tuesday' => 'Selasa',
            'Wednesday' => 'Rabu',
            'Thursday' => 'Kamis',
            'Friday' => 'Jumat',
            'Saturday' => 'Sabtu'
        );

        $namahari = date('l', strtotime($date));
        return $daftar_hari[$namahari];
    }

    function formatMoney($money = null)
    {
        return 'Rp ' . number_format($money, 0, ',', '.');
    }
}
