<footer class="main-footer">
    <strong>Copyright &copy; {{ date('Y') }} CV. ADITYA BANGUN PERKASA.</strong>
    All rights reserved.
</footer>
