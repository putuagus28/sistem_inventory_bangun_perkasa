<?php

namespace App\Http\Controllers;

use App\Barang;
use App\Penjualan;
use App\Pembelian;
use App\DetailPenjualan;
use App\DetailPembelian;
use App\Jenis;
use App\StokOpname;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Session;
use PDF;
use Illuminate\Support\Facades\DB;

class LaporanController extends Controller
{
    public function index($jenis = "")
    {
        $bulan = [
            "Januari", "Februari", "Maret", "April", "Mei", "Juni", "Juli", "Agustus",
            "September", "Oktober", "November", "Desember"
        ];
        if ($jenis == "pembelian") {
            $data = [
                'title' => 'Laporan Barang Masuk',
                'jenis' => $jenis,
                'bulan' => $bulan,
            ];
        } elseif ($jenis == "penjualan") {
            $data = [
                'title' => 'Laporan ' . ucwords($jenis),
                'jenis' => $jenis,
                'bulan' => $bulan,
            ];
        } elseif ($jenis == "stok") {
            $data = [
                'title' => 'Laporan ' . ucwords($jenis) . ' Opname',
                'jenis' => $jenis,
                'bulan' => $bulan,
                'kategori' => Jenis::orderBy('nama_jenis', 'asc')->get(),
            ];
        }
        return view('laporan.' . $jenis, $data);

        return abort(404);
    }

    public function getLaporan(Request $req)
    {
        if ($req->jenis == "pembelian") {
            $d1 = date('d-m-Y', strtotime($req->tgl_awal));
            $d2 = date('d-m-Y', strtotime($req->tgl_akhir));
            $bulan = $req->bulan;
            $tahun = $req->tahun;
            if ($req->pilihan == 'tanggal') {
                $query = Pembelian::with("user", "detail.barang")
                    ->select('*', DB::raw('DATE_FORMAT(tgl, "%d-%m-%Y") as tanggal'))
                    ->where(DB::raw('DATE_FORMAT(tgl, "%d-%m-%Y")'), '>=', $d1)
                    ->where(DB::raw('DATE_FORMAT(tgl, "%d-%m-%Y")'), '<=', $d2)
                    ->orderBy('tgl', 'desc')
                    ->get();
                $id = [];
                foreach ($query as $key => $v) {
                    $id[] = $v->id;
                }
                $query2 = DetailPembelian::with("pembelian", "barang", "supplier")
                    ->select(
                        '*',
                        DB::raw('DATE_FORMAT(created_at, "%d-%m-%Y") as tanggal'),
                        // DB::raw('sum(qty) as qtys')
                    )
                    ->whereIn('pembelians_id', $id)
                    ->orderBy('created_at', 'desc')
                    // ->groupBy('barangs_id')
                    ->get();
            } elseif ($req->pilihan == 'bulan') {
                $query = Pembelian::with("user", "detail.barang")
                    ->select('*', DB::raw('DATE_FORMAT(tgl, "%d-%m-%Y") as tanggal'))
                    ->whereMonth('tgl', $bulan)
                    ->whereYear('tgl', $tahun)
                    ->orderBy('tgl', 'desc')
                    ->get();
                $id = [];
                foreach ($query as $key => $v) {
                    $id[] = $v->id;
                }
                $query2 = DetailPembelian::with("pembelian", "barang", "supplier")
                    ->select(
                        '*',
                        DB::raw('DATE_FORMAT(created_at, "%d-%m-%Y") as tanggal'),
                        // DB::raw('sum(qty) as qtys')
                    )
                    ->whereIn('pembelians_id', $id)
                    ->orderBy('created_at', 'desc')
                    // ->groupBy('barangs_id')
                    ->get();
            } elseif ($req->pilihan == 'tahun') {
                $query = Pembelian::with("user", "detail.barang")
                    ->select('*', DB::raw('DATE_FORMAT(tgl, "%d-%m-%Y") as tanggal'))
                    ->whereYear('tgl', $tahun)
                    ->orderBy('tgl', 'desc')
                    ->get();
                $id = [];
                foreach ($query as $key => $v) {
                    $id[] = $v->id;
                }
                $query2 = DetailPembelian::with("pembelian", "barang", "supplier")
                    ->select(
                        '*',
                        DB::raw('DATE_FORMAT(created_at, "%d-%m-%Y") as tanggal'),
                        // DB::raw('sum(qty) as qtys')
                    )
                    ->whereIn('pembelians_id', $id)
                    ->orderBy('created_at', 'desc')
                    // ->groupBy('barangs_id')
                    ->get();
            }

            $data = [
                'query' => $query,
                'query2' => $query2,
            ];
        } elseif ($req->jenis == "penjualan") {
            $d1 = date('d-m-Y', strtotime($req->tgl_awal));
            $d2 = date('d-m-Y', strtotime($req->tgl_akhir));
            $bulan = $req->bulan;
            $tahun = $req->tahun;
            if ($req->pilihan == 'tanggal') {
                $query = Penjualan::with("customers", "detail.barang")
                    ->select('*', DB::raw('DATE_FORMAT(tgl, "%d-%m-%Y") as tanggal'))
                    ->where(DB::raw('DATE_FORMAT(tgl, "%d-%m-%Y")'), '>=', $d1)
                    ->where(DB::raw('DATE_FORMAT(tgl, "%d-%m-%Y")'), '<=', $d2)
                    ->orderBy('tgl', 'desc')
                    ->get();
                $id = [];
                foreach ($query as $key => $v) {
                    $id[] = $v->id;
                }
                $query2 = DetailPenjualan::with("penjualan", "barang")
                    ->select(
                        '*',
                        DB::raw('DATE_FORMAT(created_at, "%d-%m-%Y") as tanggal'),
                        DB::raw('sum(qty) as qtys')
                    )
                    ->whereIn('penjualans_id', $id)
                    ->orderBy('qtys', 'desc')
                    ->groupBy('barangs_id')
                    ->get();
            } elseif ($req->pilihan == 'bulan') {
                $query = Penjualan::with("customers", "detail.barang")
                    ->select('*', DB::raw('DATE_FORMAT(tgl, "%d-%m-%Y") as tanggal'))
                    ->whereMonth('tgl', $bulan)
                    ->whereYear('tgl', $tahun)
                    ->orderBy('tgl', 'desc')
                    ->get();
                $id = [];
                foreach ($query as $key => $v) {
                    $id[] = $v->id;
                }
                $query2 = DetailPenjualan::with("penjualan", "barang")
                    ->select(
                        '*',
                        DB::raw('DATE_FORMAT(created_at, "%d-%m-%Y") as tanggal'),
                        DB::raw('sum(qty) as qtys')
                    )
                    ->whereIn('penjualans_id', $id)
                    ->orderBy('qtys', 'desc')
                    ->groupBy('barangs_id')
                    ->get();
            } elseif ($req->pilihan == 'tahun') {
                $query = Penjualan::with("customers", "detail.barang")
                    ->select('*', DB::raw('DATE_FORMAT(tgl, "%d-%m-%Y") as tanggal'))
                    ->whereYear('tgl', $tahun)
                    ->orderBy('tgl', 'desc')
                    ->get();
                $id = [];
                foreach ($query as $key => $v) {
                    $id[] = $v->id;
                }
                $query2 = DetailPenjualan::with("penjualan", "barang")
                    ->select(
                        '*',
                        DB::raw('DATE_FORMAT(created_at, "%d-%m-%Y") as tanggal'),
                        DB::raw('sum(qty) as qtys')
                    )
                    ->whereIn('penjualans_id', $id)
                    ->orderBy('qtys', 'desc')
                    ->groupBy('barangs_id')
                    ->get();
            }
            $data = [
                'query' => $query,
                'query2' => $query2,
            ];
        } elseif ($req->jenis == "stok") {
            $d1 = date('d-m-Y', strtotime($req->tgl_awal));
            $d2 = date('d-m-Y', strtotime($req->tgl_akhir));
            $bulan = $req->bulan;
            $tahun = $req->tahun;
            if ($req->pilihan == 'tanggal') {
                $q = StokOpname::with("barang")
                    ->select('*', DB::raw('DATE_FORMAT(created_at, "%d-%m-%Y") as tanggal'))
                    ->where(DB::raw('DATE_FORMAT(created_at, "%d-%m-%Y")'), '>=', $d1)
                    ->where(DB::raw('DATE_FORMAT(created_at, "%d-%m-%Y")'), '<=', $d2)
                    ->orderBy('created_at', 'desc')
                    ->get();
            } elseif ($req->pilihan == 'bulan') {
                $q = StokOpname::with("barang")
                    ->select('*', DB::raw('DATE_FORMAT(created_at, "%d-%m-%Y") as tanggal'))
                    ->whereMonth('created_at', $bulan)
                    ->whereYear('created_at', $tahun)
                    ->orderBy('created_at', 'desc')
                    ->get();
            } elseif ($req->pilihan == 'tahun') {
                $q =  StokOpname::with("barang")
                    ->select('*', DB::raw('DATE_FORMAT(created_at, "%d-%m-%Y") as tanggal'))
                    ->whereYear('created_at', $tahun)
                    ->orderBy('created_at', 'desc')
                    ->get();
            }

            $data = [
                'query' => $q,
            ];
        }
        return response()->json($data);
    }
}
